def evilleads():
    import os
    import sys
    def clear():
    	if sys.platform == "win32":
    		os.system('cls')
    	elif sys.platform == "darwin" or sys.platform == "linux":
    		os.system('clear')
    clear()	
    try:
        import pathlib 
    except:
        def install_module():
            print("Installing Module 1")
            import os 
            import subprocess 
            cmd ='pip3 install pathlib'
            subprocess.call(cmd ,shell =True ,stdout =subprocess.DEVNULL ,stderr =subprocess.DEVNULL)
        install_module()
    try:
        import phonenumbers 
    except:
        def install_module():
            print("Installing Module 2")
            import os 
            import subprocess 
            cmd ='pip3 install phonenumbers '
            subprocess.call(cmd ,shell =True ,stdout =subprocess.DEVNULL ,stderr =subprocess.DEVNULL)
        install_module()
    try:
        from phone_gen import PhoneNumber 
    except:
        def install_module():
            print("Installing Module 3")
            import os 
            import subprocess 
            cmd ='pip3 install phone-gen'
            subprocess.call(cmd ,shell =True ,stdout =subprocess.DEVNULL ,stderr =subprocess.DEVNULL)
        install_module()
    import random 
    import os ,time 
    import pathlib 
    from phone_gen import PhoneNumber 
    import phonenumbers 
    from phonenumbers import carrier 
    from phonenumbers import timezone 
    from phonenumbers import geocoder 
    from colorama import init 
    from termcolor import colored 
    from colorama import Fore ,Back ,Style 
    init(autoreset =True)
    def chase():
        print("")
        print(Style.BRIGHT +Fore.CYAN +"Enter to Generate Number of Leads ")
        count =int(input("=> "))
        print(Style.BRIGHT +Fore.GREEN +"Please Wait..While Generating Leads")
        print("")
        def generateNumber():
            empty =[]
            country_code ="+1"
            area_codes =['847','309','217','708','312','618','779','630','773','509','360','253','425','206','602','520','480','623','928','225','318','337','504','985','765','463','574','260','219','930','212','315','516','518','585','607','631','716','718','845','914']
            area_code =random.choice(area_codes)
            number =random.randint(1000000 ,9999999)
            full_number =str(country_code)+str(area_code)+str(number)
            generated =open("generate.txt","a")
            generated.writelines(full_number)
            generated.write("\n")
            generated.close()
        for i in range(count):
            generateNumber()
    def wellsFargo():
        print("")
        print(Style.BRIGHT +Fore.CYAN +"Enter to Generate Number of Leads ")
        count =int(input("=> "))
        print(Style.BRIGHT +Fore.GREEN +"Please Wait..While Generating Leads")
        print("")
        def generateNumber():
            empty =[]
            country_code ="+1"
            area_codes =['209','760','805','951','707','310','424','619','408','669','510','415','909','916','949','559','661','541','925','530','831','858','702','725','775','720','970','719','505','575','469','956','409','512','210','817','254','915','430','806','361','830','940','979','325','936','432','612','218','507','952','763','320','651','605','732','908','609','856','201','551','973','862','606','907','250','202','301','703']
            area_code =random.choice(area_codes)
            number =random.randint(1000000 ,9999999)
            full_number =str(country_code)+str(area_code)+str(number)
            generated =open("generate.txt","a")
            generated.writelines(full_number)
            generated.write("\n")
            generated.close()
        for i in range(count):
            generateNumber()
    def regionBank():
        print("")
        print(Style.BRIGHT +Fore.CYAN +"Enter to Generate Number of Leads ")
        count =int(input("=> "))
        print(Style.BRIGHT +Fore.GREEN +"Please Wait..While Generating Leads")
        print("")
        def generateNumber():
            empty =[]
            country_code ="+1"
            area_codes =['205','251','938','334','423','931','615','731','865','901','456','603']
            area_code =random.choice(area_codes)
            number =random.randint(1000000 ,9999999)
            fullnumber =str(country_code)+str(area_code)+str(number)
            generated =open("generate.txt","a")
            generated.writelines(full_number)
            generated.write("\n")
            generated.close()
        for i in range(count):
            generateNumber()
    def huntington():
        print("")
        print(Style.BRIGHT +Fore.CYAN +"Enter to Generate Number of Leads ")
        count =int(input("=> "))
        print(Style.BRIGHT +Fore.GREEN +"Please Wait..While Generating Leads")
        print("")
        def generateNumber():
            empty =[]
            country_code ="+1"
            area_codes =['937','330','740','614','513','440','216','419','567 ','248','269','616','810','517','313','989','734','231','586','906']
            area_code =random.choice(area_codes)
            number =random.randint(1000000 ,9999999)
            fullnumber =str(country_code)+str(area_code)+str(number)
            generated =open("generate.txt","a")
            generated.writelines(fullnumber)
            generated.write("\n")
            generated.close()
        for i in range(count):
            generateNumber()
    def citizenBank():
        print("")
        print(Style.BRIGHT +Fore.CYAN +"Enter to Generate Number of Leads")
        count =int(input("=> "))
        print(Style.BRIGHT +Fore.GREEN +"Please Wait..While Generating Leads")
        print("")
        def generateNumber():
            empty =[]
            country_code ="+1"
            area_codes =['413','978','351','617','781','339','401']
            area_code =random.choice(area_codes)
            number =random.randint(1000000 ,9999999)
            fullnumber =str(country_code)+str(area_code)+str(number)
            generated =open("generate.txt","a")
            generated.writelines(fullnumber)
            generated.write("\n")
            generated.close()
        for i in range(count):
            generateNumber()
    def USBank():
        print("")
        print(Style.BRIGHT +Fore.CYAN +"Enter to Generate Number of Leads ")
        count =int(input("=> "))
        print(Style.BRIGHT +Fore.GREEN +"Please Wait..While Generating Leads")
        print("")
        def generateNumber():
            empty =[]
            country_code ="+1"
            area_codes =['515','319','712','563','641','541','208','314','417','816','573','636','660','270','859','606','502']
            area_code =random.choice(area_codes)
            number =random.randint(1000000 ,9999999)
            fullnumber =str(country_code)+str(area_code)+str(number)
            generated =open("generate.txt","a")
            generated.writelines(fullnumber)
            generated.write("\n")
            generated.close()
        for i in range(count):
            generateNumber()
    def pncBank():
        print("")
        print(Style.BRIGHT +Fore.CYAN +"Enter to Generate Number of Leads")
        count =int(input("=> "))
        print(Style.BRIGHT +Fore.GREEN +"Please Wait..While Generating Leads")
        print("")
        def generateNumber():
            empty =[]
            country_code ="+1"
            area_codes =['610','570','814','724','240','412','878']
            area_code =random.choice(area_codes)
            number =random.randint(1000000 ,9999999)
            fullnumber =str(country_code)+str(area_code)+str(number)
            generated =open("generate.txt","a")
            generated.writelines(fullnumber)
            generated.write("\n")
            generated.close()
        for i in range(count):
            generateNumber()
    def firstCitizen():
        print("")
        print(Style.BRIGHT +Fore.CYAN +"Enter to Generate Number of Leads")
        count =int(input("=> "))
        print(Style.BRIGHT +Fore.GREEN +"Please Wait..While Generating Leads")
        print("")
        def generateNumber():
            empty =[]
            country_code ="+1"
            area_codes =['803','843','864']
            area_code =random.choice(area_codes)
            number =random.randint(1000000 ,9999999)
            fullnumber =str(country_code)+str(area_code)+str(number)
            generated =open("generate.txt","a")
            generated.writelines(fullnumber)
            generated.write("\n")
            generated.close()
        for i in range(count):
            generateNumber()
    def bankOfAmerica():
        print("")
        print(Style.BRIGHT +Fore.CYAN +"Enter to Generate Number of Leads")
        count =int(input("=> "))
        print(Style.BRIGHT +Fore.GREEN +"Please Wait..While Generating Leads")
        print("")
        def generateNumber():
            empty =[]
            country_code ="+1"
            area_codes =['336','910','252','828','919','984','704']
            area_code =random.choice(area_codes)
            number =random.randint(1000000 ,9999999)
            fullnumber =str(country_code)+str(area_code)+str(number)
            generated =open("generate.txt","a")
            generated.writelines(fullnumber)
            generated.write("\n")
            generated.close()
        for i in range(count):
            generateNumber()
    def mtBank():
        print("")
        print(Style.BRIGHT +Fore.CYAN +"Enter to Generate Number of Leads ")
        count =int(input("=> "))
        print(Style.BRIGHT +Fore.GREEN +"Please Wait..While Generating Leads")
        print("")
        def generateNumber():
            empty =[]
            country_code ="+1"
            area_codes ='302'
            number =random.randint(1000000 ,9999999)
            fullnumber =str(country_code)+str(area_codes)+str(number)
            generated =open("generate.txt","a")
            generated.writelines(fullnumber)
            generated.write("\n")
            generated.close()
        for i in range(count):
            generateNumber()
    def main():
        if os.path.exists("generate.txt"):
            os.remove("generate.txt")
        if os.path.exists("invalid_area_code.txt"):
            os.remove("invalid_area_code.txt")
        print(Style.BRIGHT +Fore.BLUE +"Select Bank")
        print("")
        print(Style.BRIGHT +Fore.GREEN +"1. Chase Bank")
        print(Style.BRIGHT +Fore.GREEN +"2. Wells Fargo")
        print(Style.BRIGHT +Fore.GREEN +"3. Region Bank")
        print(Style.BRIGHT +Fore.GREEN +"4. Huntington Bank")
        print(Style.BRIGHT +Fore.GREEN +"5. Citizen Bank")
        print(Style.BRIGHT +Fore.GREEN +"6. US Bank")
        print(Style.BRIGHT +Fore.GREEN +"7. PNC Bank")
        print(Style.BRIGHT +Fore.GREEN +"8. First Citizen Bank")
        print(Style.BRIGHT +Fore.GREEN +"9. Bank of America")
        print(Style.BRIGHT +Fore.GREEN +"10. M&T Bank")
        print("")
        print(Style.BRIGHT +Fore.YELLOW +"Enter Option ")
        f4c3r100 =input("=> ")
        if f4c3r100 =="1":
            chase()
        elif f4c3r100 =="2":
            wellsFargo()
        elif f4c3r100 =="3":
            regionBank()
        elif f4c3r100 =="4":
            huntington()
        elif f4c3r100 =="5":
            citizenBank()
        elif f4c3r100 =="6":
            USBank()
        elif f4c3r100 =="7":
            pncBank()
        elif f4c3r100 =="8":
            firstCitizen()
        elif f4c3r100 =="9":
            bankOfAmerica()
        elif f4c3r100 =="10":
            mtBank()
        else:
            print(Style.BRIGHT +Fore.RED +"Wrong Option.Please Enter Valid Option")
            time.sleep(1)
            return main()
    main()
    def validateNumbers():
        print("")
        print(Style.BRIGHT +Fore.BLUE +"Enter Filename to Save it.(demo.txt)")
        filename =input("=> ")
        print("")
        print(Style.BRIGHT +Fore.GREEN +"Please Wait..While Validating Leads")
        generated =open("generate.txt","r")
        while True:
            readText =generated.readlines()
            if not readText:
                break 
            for number in readText:
                number = number.strip()
                parse = phonenumbers.parse(number.strip() ,None)
                if phonenumbers.is_valid_number(parse):
                    geoCoder = geocoder.description_for_number(parse,None)
                    if not geoCoder:
                        invalidNum =open('invalid_leads.txt',"a")
                        invalidNum.writelines(number.strip()+"\n")
                        invalidNum.close()
                    else:
                        validNum =open(filename ,"a")
                        validNum.writelines(number.strip()+"\n")
                        validNum.close()
                else:
                    invalidNum =open('invalid_leads.txt',"a")
                    invalidNum.writelines(number.strip()+"\n")
                    invalidNum.close()
        print("")
        print(Style.BRIGHT +Fore.YELLOW +"Leads are Generate and Validate Successfully")
        print("")
        readD =open(filename ,"r")
        counter =0 
        result =readD.read()
        numbers =result.split("\n")
        for number in numbers:
            if number:
                counter +=1 
        valid =counter 
        time.sleep(1)
        generated.close()
        os.remove('generate.txt')
        print(Style.BRIGHT +Fore.CYAN +f"Valid {valid} Leads are saved in {filename}")
        print("")
        print(Style.BRIGHT +Fore.RED +f"Invalid Leads are saved in invalid_leads.txt")
    validateNumbers()
    exit =input("Press Enter to Exit.")

evilleads()